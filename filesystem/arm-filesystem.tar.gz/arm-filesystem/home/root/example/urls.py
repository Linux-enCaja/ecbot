from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^polls/$', 'example.polls.views.index'),
    (r'^polls/(?P<poll_id>\d+)/$', 'example.polls.views.detail'),
    (r'^polls/(?P<poll_id>\d+)/results/$', 'example.polls.views.results'),
    (r'^polls/(?P<poll_id>\d+)/vote/$', 'example.polls.views.vote'),
)


